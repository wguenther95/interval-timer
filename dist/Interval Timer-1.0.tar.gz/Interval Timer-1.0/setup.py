import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(name='Interval Timer',
                 version='1.0',
                 description='Python Interval Timer',
                 author='Wes Guenther',
                 author_email='guenthwd@miamioh.edu',
                 packages=setuptools.find_packages(),
                 )
