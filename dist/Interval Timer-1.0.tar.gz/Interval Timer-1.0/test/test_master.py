import ..interval_timer

if __name__ == '__main__':
    TimerController()
