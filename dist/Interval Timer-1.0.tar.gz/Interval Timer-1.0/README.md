# Interval Timer

### Description
--------------------
A timer application written in Python to be used for timing intervals when performing high intensity interval training (HIIT).
